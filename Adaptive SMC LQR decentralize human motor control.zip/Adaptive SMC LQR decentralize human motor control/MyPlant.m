function [x]= MyPlant(x,input)
g = 9.81; % m/s^2
L1= 1; L2 = 1; %m
r1= 0.5; r2 = 0.5; %m
m1 = 3; m2 = 2; %kg
I1 = 2; I2 = 1; %kg*m^2


dt=0.001;

theta_ddot_ =[                                                                                                          -(cos(x(1) - x(2))*sin(x(1) - x(2))*L1^2*m2^2*r2^2*x(3)^2 + g*cos(x(1) - x(2))*sin(x(2))*L1*m2^2*r2^2 + I2*sin(x(1) - x(2))*L1*m2*r2*x(4)^2 + input(2)*cos(x(1) - x(2))*L1*m2*r2 - I2*g*sin(x(1))*L1*m2 - I2*input(1) - I2*g*m1*r1*sin(x(1)))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(x(1) - x(2))^2);
   (I1*input(2) + L1^2*m2*input(2) - L1*m2*r2*input(1)*cos(x(1) - x(2)) + L1^3*m2^2*r2*x(3)^2*sin(x(1) - x(2)) + L1^2*g*m2^2*r2*sin(x(2)) + I1*g*m2*r2*sin(x(2)) + (L1^2*m2^2*r2^2*x(4)^2*sin(2*x(1) - 2*x(2)))/2 - L1^2*g*m2^2*r2*cos(x(1) - x(2))*sin(x(1)) + I1*L1*m2*r2*x(3)^2*sin(x(1) - x(2)) - L1*g*m1*m2*r1*r2*cos(x(1) - x(2))*sin(x(1)))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(x(1) - x(2))^2)];



x=[x(3);
     x(4);
     theta_ddot_]*dt+x;
 
end