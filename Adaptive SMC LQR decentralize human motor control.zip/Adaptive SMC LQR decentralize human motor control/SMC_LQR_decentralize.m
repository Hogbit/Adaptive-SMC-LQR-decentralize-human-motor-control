close all
clear 
A_linear = [        0,        0, 1, 0
                    0,        0, 0, 1
             2289/200, -327/100, 0, 0
            -2289/200,   327/25, 0, 0];
 
 
B_linear = [  0,    0
              0,    0
            1/3, -1/3
           -1/3,  4/3];
     
           
Q = diag([1e0 1e0 1e0 1e0])*1e1;
R = diag([5 5])*1e0;
K_lqr_ini = lqr(A_linear,B_linear,Q,R);% K_lqr 


S_ini=rand(2,4);% initial random sliding surface

A11 = A_linear(1:2,1:2);
A12 = A_linear(1:2,3:4);
A21 = A_linear(3:4,1:2);
A22 = A_linear(3:4,3:4);
Q11 = Q(1:2,1:2);
Q12 = Q(1:2,3:4);
Q22 = Q(3:4,3:4);
A_hat = A11-A12*(Q22\Q12');
Q_hat = Q11-Q12*(Q22\Q12');
Ob = obsv(A_hat,Q_hat^0.5);
unob = length(A_hat)-rank(Ob);
B_hat = B_linear(3:4,1:2);
K = lqr(A_hat,A12,Q_hat,Q22);
P_hat = A12'\Q22*K;
M = Q22\Q12'+Q22\A12'*P_hat;
S = [M,eye(2)]


sim('linear_modela_adaptive_SMC_LQR_decentralize')

Ts=1e-3;    % sampling time%%%% drawing %%%%
figure(1)
subplot(3,1,1)
plot(simTime,tau.Data(:,1))
hold on
grid on
plot(simTime,tau.Data(:,2))
title('\tau1 and \tau2')
legend('\tau1','\tau2')
subplot(3,1,2)
plot(simTime,q.Data(:,1))
hold on
grid on
title('First joint angle \theta1')

subplot(3,1,3)
plot(simTime,q.Data(:,2))
grid on
hold on
title('Second joint angle \theta2')
xlabel('time')
hold off

figure(2)
subplot(2,1,1)
plot(simTime,Slinding_variable.Data(:,1))
grid on
hold on
title('Sliding Varibable \sigma')
xlabel('time')

subplot(2,1,2)
plot(simTime,Sign_sigma.Data(:,1))
grid on
hold on
title('Time history of sign(\sigma)')
xlabel('time')
hold off




x1 = decimate(postition.Data(:,1), 10);
y1 = decimate(postition.Data(:,2), 10);

x2 = decimate(postition.Data(:,3), 10);
y2 = decimate(postition.Data(:,4), 10);

theta1 =  decimate(q.Data(:,1), 10);
theta2 =  decimate(q.Data(:,2), 10);

h = figure('Position',[400 200 500 420]);

% rectangle('Position',[x-W/2,y-H/2,W,H],'Curvature',.1,'FaceColor',[1 0.1 0.1])

filename = 'Double_inverted_pendulum_SMC_LQR.gif';
% plot([postition.Data(:,1),postition.Data(:,3)],[postition.Data(:,2),postition.Data(:,4)])
for k = 1:(length(simTime)-1)/10+1
    plot([x1(k),0],[y1(k),0],'b-','LineWidth',6.0)
    hold on
    grid on
    plot([x2(k),x1(k)],[y2(k),y1(k)],'r-','LineWidth',6.0)
    plot([0,0],[-0.1,2.4],'--');
    plot([x1(k),x1(k)],[-0.1,2.4],'--')
    title({'Adaptive SMC and LQR controlller' '\theta_1: ' num2str(rad2deg(theta1(k)),2)  '\theta_2: ' num2str(rad2deg(theta2(k)),2) })
    hold off
    drawnow
   
    ylim([-0.1 2.4])
    xlim([-2 2])

      % Capture the plot as an image 
      frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,512); 
      % Write to the GIF File 
      if k == 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf,'DelayTime',Ts*10); 
      else 
          imwrite(imind,cm,filename,'WriteMode','append','DelayTime',Ts*10); 
      end 
end
% 
% 
% for k = 1:(length(simTime)-1)/100+1
%     yy = cos(X3d(k));
%     yx = sin(X3d(k));
%     x(1) = X1d(k)-1;
%     x(2) = X1d(k)+1;
%     plot(x,[0 0],'g-','LineWidth',5.5)
%     ylim([-0.1 1.1])
%     xlim([-3 3])
%     hold on
%     grid on
%     plot([X1d(k) X1d(k)+yx],[0 yy],'b-','LineWidth',8.0)
%     title({'Sliding mode control' 'pos: ' num2str(X1d(k),2)  '  angle: ' num2str(X3d(k),2) })
%     hold off
% end