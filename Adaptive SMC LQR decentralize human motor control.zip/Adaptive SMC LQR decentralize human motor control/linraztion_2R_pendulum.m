
%calculate linraztion of 2R pendulum
% g = 9.81; % m/s^2
% L1= 1; L2 = 1; %m
% r1= 0.5; r2 = 0.5; %m
% m1 = 3; m2 = 2; %kg
% I1 = 2; I2 = 1; %kg*m^2
syms theta1 theta2 theta_dot1 theta_dot2 theta_ddot1 theta_ddot2 tau1 tau2 g L1 L2 r1 r2 m1 m2 I1 I2 real
theta(1)=theta1;
theta(2)=theta2;
theta_dot(1)=theta_dot1;
theta_dot(2)=theta_dot2;
theta_ddot(1)=theta_ddot1;
theta_ddot(2)=theta_ddot2;

u=[tau1,tau2]';

% M = [I1+I2+(L1^2)*m2+2*L1*m2*r2*cos(theta(2)), I2+L1*m2*r2*cos(theta(2));
%      I2+L1*m2*r2*cos(theta(2)), I2];
% % C = [-2*L1*m2*r2*sin(theta(2))*theta_dot(2), -L1*m2*r2*sin(theta(2))*theta_dot(2);
% %      L1*m2*r2*sin(theta(2))*theta_dot(1),                                     0];
% % G = [g*(L1*m2+m1*r1)*cos(theta(1))+g*m2*r2*cos(theta(1)+theta(2));
% %      g*m2*r2*cos(theta(1)+theta(2))];
% h = [-2*L1*m2*r2*sin(theta(2))*theta_dot(2)*theta_dot(1)-L1*m2*r2*sin(theta(2))*theta_dot(2)*theta_dot(2)+g*(L1*m2+m1*r1)*cos(theta(1))+g*m2*r2*cos(theta(1)+theta(2));
%      L1*m2*r2*sin(theta(2))*theta_dot(1)*theta_dot(1)+g*m2*r2*cos(theta(1)+theta(2))];
 
%  %%%% 0 value equilibrium positon
% M = [I1+L1^2*m2, L1*m2*r2*cos(theta(1)-theta(2));
%      L1*m2*r2*cos(theta(1)-theta(2)), I2];
% h = [g*(L1*m2 + m1*r1)*cos(theta(1)) + L1*m2*r2*sin(theta(1)-theta(2))*theta_dot(2)^2;
%      m2*r2*(g*cos(theta(2)) - L1*sin(theta(1)-theta(2))*theta_dot(1)^2) ];
 %%%% 0 value equilibrium positon ?Vertical?
M = [I1+L1^2*m2, L1*m2*r2*cos(theta(1)-theta(2));
     L1*m2*r2*cos(theta(1)-theta(2)), I2];
h = [g*(-L1*m2 - m1*r1)*sin(theta(1)) + L1*m2*r2*sin(theta(1)-theta(2))*theta_dot(2)^2;
     m2*r2*(-g*sin(theta(2)) - L1*sin(theta(1)-theta(2))*theta_dot(1)^2) ];-h
% theta_ddot_ =[                                                                                                      -(cos(q(1) - q(2))*sin(q(1) - q(2))*L1^2*m2^2*r2^2*q(3)^2 + g*cos(q(1) - q(2))*sin(q(2))*L1*m2^2*r2^2 + I2*sin(q(1) - q(2))*L1*m2*r2*q(4)^2 + u(2)*cos(q(1) - q(2))*L1*m2*r2 - I2*g*sin(q(1))*L1*m2 - I2*u(1) - I2*g*m1*r1*sin(q(1)))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(q(1) - q(2))^2);
%               (I1*u(2) + L1^2*m2*u(2) - L1*m2*r2*u(1)*cos(q(1) - q(2)) + L1^3*m2^2*r2*q(3)^2*sin(q(1) - q(2)) + L1^2*g*m2^2*r2*sin(q(2)) + I1*g*m2*r2*sin(q(2)) + (L1^2*m2^2*r2^2*q(4)^2*sin(2*q(1) - 2*q(2)))/2 - L1^2*g*m2^2*r2*cos(q(1) - q(2))*sin(q(1)) + I1*L1*m2*r2*q(3)^2*sin(q(1) - q(2)) - L1*g*m1*m2*r1*r2*cos(q(1) - q(2))*sin(q(1)))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(q(1) - q(2))^2)];

 
 
 
 
theta_ddot = M\(-h+u)
theta_ddot_=simplify(theta_ddot)
pretty(simplify(theta_ddot))

% theta_ddot_ =[                                                                                                          -(cos(q(1) - q(2))*sin(q(1) - q(2))*L1^2*m2^2*r2^2*q(3)^2 - g*cos(q(1) - q(2))*cos(q(2))*L1*m2^2*r2^2 + I2*sin(q(1) - q(2))*L1*m2*r2*q(4)^2 + u(2)*cos(q(1) - q(2))*L1*m2*r2 + I2*g*cos(q(1))*L1*m2 - I2*u(1) + I2*g*m1*r1*cos(q(1)))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(q(1) - q(2))^2)
%               (I1*u(2) + L1^2*m2*u(2) - L1*m2*r2*u(1)*cos(q(1) - q(2)) + L1^3*m2^2*r2*q(3)^2*sin(q(1) - q(2)) - L1^2*g*m2^2*r2*cos(q(2)) - I1*g*m2*r2*cos(q(2)) + (L1^2*m2^2*r2^2*q(4)^2*sin(2*q(1) - 2*q(2)))/2 + L1^2*g*m2^2*r2*cos(q(1) - q(2))*cos(q(1)) + I1*L1*m2*r2*q(3)^2*sin(q(1) - q(2)) + L1*g*m1*m2*r1*r2*cos(q(1) - q(2))*cos(q(1)))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(q(1) - q(2))^2)];
% 

% theta_ddot_ =[                                                                                                       -(cos(theta1 - theta2)*sin(theta1 - theta2)*L1^2*m2^2*r2^2*theta_dot1^2 - g*cos(theta1 - theta2)*cos(theta2)*L1*m2^2*r2^2 + I2*sin(theta1 - theta2)*L1*m2*r2*theta_dot2^2 + tau2*cos(theta1 - theta2)*L1*m2*r2 + I2*g*cos(theta1)*L1*m2 - I2*tau1 + I2*g*m1*r1*cos(theta1))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(theta1 - theta2)^2)
%  (I1*tau2 + L1^2*m2*tau2 - L1*m2*r2*tau1*cos(theta1 - theta2) + L1^3*m2^2*r2*theta_dot1^2*sin(theta1 - theta2) - L1^2*g*m2^2*r2*cos(theta2) - I1*g*m2*r2*cos(theta2) + (L1^2*m2^2*r2^2*theta_dot2^2*sin(2*theta1 - 2*theta2))/2 + L1^2*g*m2^2*r2*cos(theta1 - theta2)*cos(theta1) + I1*L1*m2*r2*theta_dot1^2*sin(theta1 - theta2) + L1*g*m1*m2*r1*r2*cos(theta1 - theta2)*cos(theta1))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(theta1 - theta2)^2)];

% sin(theta1)=1;%pi/2
% sin(theta2)=theta2;%0
% 
% g = 9.81; % m/s^2
% L1= 1; L2 = 1; %m
% r1= 0.5; r2 = 0.5; %m
% m1 = 3; m2 = 2; %kg
% I1 = 2; I2 = 1; %kg*m^2
% ans = subs(theta_ddot_)