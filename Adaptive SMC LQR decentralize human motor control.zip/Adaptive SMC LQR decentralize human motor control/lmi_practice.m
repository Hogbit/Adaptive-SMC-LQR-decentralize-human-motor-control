syms theta1 theta2 theta_dot1 theta_dot2 theta_ddot1 theta_ddot2 tau1 tau2 real

g = 9.81; % m/s^2
L1= 1; L2 = 1; %m
r1= 0.5; r2 = 0.5; %m
m1 = 3; m2 = 2; %kg
I1 = 2; I2 = 1; %kg*m^2

u=[tau1,tau2]';
theta_ddot_ =[
 
                                                                                                                                                                                                                                                                                                                                                                                                     ((2*theta2*L1^2*m2^2*r2^2*theta_dot1^2)/2 + g*cos(theta1 + theta2)*cos(theta2)*L1*m2^2*r2^2 + I2*sin(theta2)*L1*m2*r2*theta_dot1^2 + 2*I2*sin(theta2)*L1*m2*r2*theta_dot1*theta_dot2 + I2*sin(theta2)*L1*m2*r2*theta_dot2^2 - tau2*cos(theta2)*L1*m2*r2 - I2*g*cos(theta1)*L1*m2 + I2*tau1 - I2*tau2 - I2*g*m1*r1*cos(theta1))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(theta2)^2);
 -(I2*tau1 - I1*tau2 - I2*tau2 - L1^2*m2*tau2 + L1^3*m2^2*r2*theta_dot1^2*sin(theta2) + L1^2*g*m2^2*r2*cos(theta1 + theta2) + I1*g*m2*r2*cos(theta1 + theta2) - I2*L1*g*m2*cos(theta1) + L1^2*m2^2*r2^2*theta_dot1^2*2*theta2 + (L1^2*m2^2*r2^2*theta_dot2^2*2*theta2)/2 - I2*g*m1*r1*cos(theta1) + L1*m2*r2*tau1*cos(theta2) - 2*L1*m2*r2*tau2*cos(theta2) + L1*g*m2^2*r2^2*cos(theta1 + theta2)*cos(theta2) - L1^2*g*m2^2*r2*cos(theta1)*cos(theta2) + I1*L1*m2*r2*theta_dot1^2*sin(theta2) + I2*L1*m2*r2*theta_dot1^2*sin(theta2) + I2*L1*m2*r2*theta_dot2^2*sin(theta2) + L1^2*m2^2*r2^2*theta_dot1*theta_dot2*2*theta2 + 2*I2*L1*m2*r2*theta_dot1*theta_dot2*sin(theta2) - L1*g*m1*m2*r1*r2*cos(theta1)*cos(theta2))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(theta2)^2)];

x_dot=[theta_dot1;
     theta_dot2;
     theta_ddot_];

 q=[theta1;
   theta2;
   theta_dot1;
   theta_dot2];

u=[tau1;
    tau2];

aaans = jacobian(theta_ddot_,[theta1,theta2]');
AA=jacobian(x_dot,q);
theta1=pi/2;
theta2=0;
theta_dot1=0;
theta_dot2=0;
A_linear=subs(AA)

% A_linear =[    0,        0, 1, 0
%           0,        0, 0, 1
%       327/40, -327/100, 0, 0
%      -327/50,   327/20, 0, 0]
 
BB=jacobian(x_dot,u);
B_linear=subs(BB)
% B_linear =[    0,    0]
%                0,    0
%              1/3, -2/3
%             -2/3,  7/3]
Co=ctrb(A_linear,B_linear)
length(A_linear) - rank(Co)
[K,prec,message]= place(A_linear,B_linear,[-1 -1 -1 -1])
% 

% theta_dot1=  ((sin(2*q(2))*L1^2*m2^2*r2^2*q(3)^2)/2 + g*cos(q(1) + q(2))*cos(q(2))*L1*m2^2*r2^2 + I2*sin(q(2))*L1*m2*r2*q(3)^2 + 2*I2*sin(q(2))*L1*m2*r2*q(3)*q(4) + I2*sin(q(2))*L1*m2*r2*q(4)^2 - u(2)*cos(q(2))*L1*m2*r2 - I2*g*cos(q(1))*L1*m2 + I2*u(1) - I2*u(2) - I2*g*m1*r1*cos(q(1)))/(I1*I2 + I2*L1^2*m2 - L1^2*m2^2*r2^2*cos(q(2))^2);