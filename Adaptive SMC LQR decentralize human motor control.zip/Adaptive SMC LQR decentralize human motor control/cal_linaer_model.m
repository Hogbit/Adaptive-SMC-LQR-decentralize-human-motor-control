[A,B,C,D]=linmod('linear_model_derive',[pi/2,0,0,0]',[0,0,0,0]')

%% Linearize Model Using Specified I/O Set
%%
% Open the Simulink model.
mdl = 'watertank';
open_system(mdl)

%%
% Specify a linearization input at the output of the PID Controller block,
% which is the input signal for the Water-Tank System block.
io(1) = linio('watertank/PID Controller',1,'input');

%%
% Specify a linearization output point at the output of the Water-Tank
% System block. Specifying the output point as open-loop removes the
% effects of the feedback signal on the linearization without changing the
% model operating point.
io(2) = linio('watertank/Water-Tank System',1,'openoutput');

%%
% Linearize the model using the specified I/O set.
linsys = linearize(mdl,io);

%%
% |linsys| is the linear approximation of the plant at the model operating
% point.