function y = MyMeasurement(x)

y=x;
end