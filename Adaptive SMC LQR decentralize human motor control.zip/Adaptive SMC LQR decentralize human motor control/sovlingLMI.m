% cal LMI
A=[0 0 1 0
   0 0 0 1
   327/40 -327/100 0 0
    -327/50 327/20 0 0];
Ad=[0 0 0 0 
    0 0 0 0
    0 0 0 0
    0 0 0 0];
B=[0 0 1 1]';

A = [-1.8 0.3 0
     0 1.5 0
     0 0.5 -2];
Ad = [-1 0 0
    -0.2 0.5 0
       0  0.2 0.6];
B = [0 0 1]';
g(x(t))=[(0.08*x1)/(2*x2^2+1) 0.1*x3*sin(x3) 0.1*x3*cos(x3)]';

rou=0.2;
% LMI
setlmis([])

X=lmivar(1,[4,1]);
V=lmivar(1,[4,1]);
L=lmivar(2,[1,4]);

% X=lmivar(1,[3,1]);
% V=lmivar(1,[3,1]);
% L=lmivar(2,[1,3]);


%define lmi term
% lmiterm([1 1 1 X],A,1);
% lmiterm([1 1 1 X], 1, A');
% lmiterm([1 1 1 L],-B,1);
% lmiterm([1 1 1 -L],1,-B');

lmiterm([-1 1 1 X], 1, 1);
lmiterm([-3 1 1 V], 1, 1);

lmiterm([2 1 1 X],A,1,'s');
lmiterm([2 1 1 L],-B,1,'s');
lmiterm([2 1 1 0],1);

lmiterm([2 1 2 V],Ad,1);
% lmiterm([2 2 1 V],1,Ad');

lmiterm([2 1 3 X],1,1);
lmiterm([2 1 4 X],1,1);

% lmiterm([2 3 1 X],1,1);
% lmiterm([2 4 1 X],1,1);

lmiterm([2 2 2 V],-1,1);
lmiterm([2 3 3 V],-1,1);

lmiterm([2 4 4 0],-1/rou);

lmiterm([2 2 3 0],zeros(3,3));
lmiterm([2 2 4 0],zeros(3,3));
lmiterm([2 3 2 0],zeros(3,3));
lmiterm([2 3 4 0],zeros(3,3));
lmiterm([2 4 2 0],zeros(3,3));
lmiterm([2 4 3 0],zeros(3,3));




LMISYS = getlmis; 
[tmin,xfeas] = feasp(LMISYS)
tmin
X = dec2mat(LMISYS,xfeas,X);  %getting the value of lmi variable
V = dec2mat(LMISYS,xfeas,V);
L = dec2mat(LMISYS,xfeas,L);


%%%% verify %%%%

X = [1.4129 0.0840      0
     0.084   1.5475     0
     0        0    0.9389];
V = [2.7784 -0.1559 0.0101
     -0.1559  3.9596 -0.2555
     0.0101 -0.2555 3.8022];
L = [0.0420 -0.7738 0.9694];

LMI_lhs=[A*X+X*A'-B*L-L'*B'+eye(3,3) Ad*V             X            X;
    V*Ad'                              -V      zeros(3,3)  zeros(3,3);
    X                           zeros(3,3)           -V     zeros(3,3);
    X                           zeros(3,3)    zeros(3,3) (-1/rou).*eye(3,3)];

% LMI_lhs=[A*X+X*A'-B*L-L'*B'+eye(4,4) Ad*V             X            X;
%     V*Ad'                              -V      zeros(4,4)  zeros(4,4);
%     X                           zeros(4,4)           -V     zeros(4,4);
%     X                           zeros(4,4)    zeros(4,4) (-1/rou)*eye(4,4)];
% 
    
eig_LMI_lhs=eig(LMI_lhs)
   
try chol(-LMI_lhs)
    disp('Matrix is symmetric positive definite.')
catch ME
    disp('Matrix is not symmetric positive definite')
end
%  [tmin, feas] = feasp(LMISYS)