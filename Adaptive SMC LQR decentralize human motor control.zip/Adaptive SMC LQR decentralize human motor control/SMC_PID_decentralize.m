A_linear = [        0,        0, 1, 0
                    0,        0, 0, 1
             2289/200, -327/100, 0, 0
            -2289/200,   327/25, 0, 0]
 
 
B_linear = [  0,    0
              0,    0
            1/3, -1/3
           -1/3,  4/3]
     
           
Q = diag([1e0 1e0 1e0 1e0])*1e1;
R = diag([1 1])*1e1;
S1 = lqr(A_linear,B_linear,Q,R);
S_ini=rand(2,4);

% A11 = A_linear(1:2,1:2);
% A12 = A_linear(1:2,3:4);
% A21 = A_linear(3:4,1:2);
% A22 = A_linear(3:4,3:4);
% Q11 = Q(1:2,1:2);
% Q12 = Q(1:2,3:4);
% Q22 = Q(3:4,3:4);
% A_hat = A11-A12*(Q22\Q12');
% Q_hat = Q11-Q12*(Q22\Q12');
% Ob = obsv(A_hat,Q_hat^0.5);
% unob = length(A_hat)-rank(Ob);
% B_hat = B_linear(3:4,1:2);
% K = lqr(A_hat,A12,Q_hat,Q22);
% P_hat = -B_hat'\Q22*K;
% M = Q22\Q12'+Q22\A12'*P_hat;
% S = [M,eye(2)]





sim('linear_model_SMC_PID_decentralize')

%%%% drawing %%%%
figure
subplot(3,1,1)
plot(simTime,u.Data(:,1))
hold on
grid on
plot(simTime,u.Data(:,2))
title('\tau1 and \tau2')
legend('\tau1','\tau2')
subplot(3,1,2)
plot(simTime,q.Data(:,1))
hold on
grid on
title('First joint angle \theta1')

subplot(3,1,3)
plot(simTime,q.Data(:,2))
grid on
hold on
title('Second joint angle \theta2')
xlabel('time')
hold off



x1 = decimate(postition.Data(:,1), 100)
y1 = decimate(postition.Data(:,2), 100)

x2 = decimate(postition.Data(:,3), 100)
y2 = decimate(postition.Data(:,4), 100)


% 
% % plot([postition.Data(:,1),postition.Data(:,3)],[postition.Data(:,2),postition.Data(:,4)])
% for k = 1:(length(simTime)-1)/100+1
%     plot([x1,y1],[0,0],'b-','LineWidth',6.0)
%     hold on
%     grid on
%     plot([x2,y2],[x1,y1],'g-','LineWidth',6.0)
%     hold off
%     drawnow
% end
% 
% 
% for k = 1:(length(simTime)-1)/100+1
%     yy = cos(X3d(k));
%     yx = sin(X3d(k));
%     x(1) = X1d(k)-1;
%     x(2) = X1d(k)+1;
%     plot(x,[0 0],'g-','LineWidth',5.5)
%     ylim([-0.1 1.1])
%     xlim([-3 3])
%     hold on
%     grid on
%     plot([X1d(k) X1d(k)+yx],[0 yy],'b-','LineWidth',8.0)
%     title({'Sliding mode control' 'pos: ' num2str(X1d(k),2)  '  angle: ' num2str(X3d(k),2) })
%     hold off
% end